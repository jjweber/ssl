<?php

// Section 1
class helloClass{
    public function greeting() {
        echo "Hello World";
    }
}

$sayHelloClass = new helloClass();
$sayHelloClass->greeting();

?>