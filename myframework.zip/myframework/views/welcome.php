<style>
    body{background: blue; color: #FFF; text-align: center;}
</style>
<p>Welcome page here!</p>

<div id="mainBody" class="container-fluid">
    <div class="jumbotron">
        <h1>The Body!</h1>
        <p>
            Some stuff ....
        </p>
    </div>
        
    
</div>