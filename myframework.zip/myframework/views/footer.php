        <footer>
            <p>Footer &copy; Company 2017</p>
        </footer>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
        <script>window.jQuery || document.write('<script src="/assets/js/vendor/jquery-3.2.1.min.js"><\/script>')</script>
        <script src="/assets/js/vendor/popper.min.js"></script>
        <script src="/assets/js/bootstrap.min.js"></script>
        <script src="/assets/js/main.js"></script>
    </body>
</html>




<!--

[X] Use modals from http://v4-alpha.getbootstrap.com/components/modal/
[X] Use carousel from http://v4-alpha.getbootstrap.com/components/carousel/
[X] Use progress bar from http://v4-alpha.getbootstrap.com/components/progress/
[X] Use popovers from http://v4-alpha.getbootstrap.com/components/popovers/
[X] Make sure to create these functionalities on at least 2 different views.
[X] Create a separate controller and make sure your navigation bar has a button/link to this controller
-->